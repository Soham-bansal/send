var indexSectionsWithContent =
{
  0: "1234789abcdefghijklmnopqrstuvwxy",
  1: "g",
  2: "bcgimnqvw",
  3: "g",
  4: "abdghprsuw",
  5: "g",
  6: "g",
  7: "abcefghijkmnrstvw",
  8: "234abcdfgilmnrstvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros",
  7: "Modules",
  8: "Pages"
};

